
function login(){
  const button = document.getElementById('sign-in');
  button.addEventListener('click', function(e) {
    var username = document.getElementById('username');
    var password = document.getElementById('pass');
    const https = require("https");
    const url = "http://localhost:3000/api/frontend/v1/frontendUsers/:id";
    https.get(url, res => {
      res.setEncoding("utf8");
      let body = "";
      res.on("data", data => {
        body += data;
      });
      res.on("end", () => {
        body = JSON.parse(body);
        console.log(body);
      });
    });

  })};
