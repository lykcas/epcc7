var path = require("path");

// Get the database model
databaseModule = require(path.join(process.cwd(),"modules/database")); 
var logger = require('../modules/logger').logger();

/**
 * Create object data
 * 
 * @param  {[type]}   modelName Model name
 * @param  {[type]}   obj       Model object
 * @param  {Function} cb        Call back
 */
module.exports.create = function(modelName,obj,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.create(obj,cb);
}

/**
 * Get all data
 * 
 * @param  {[type]}   conditions Query conditions
 *Unified query criteria
 * conditions
	{
		"columns" : {
			Field conditions
			"Field name" : "Condition value"
		},
		"offset" : "Offset",
		"omit" : ["Field"],
		"only" : ["Required field"],
		"limit" : "",
		"order" :[ 
			"Field" , A | Z,
			...
		]
	}
 * @param  {Function} cb          Call back
 */
module.exports.list = function(modelName,conditions,cb) {
	var db = databaseModule.getDatabase();

	var model = db.models[modelName];

    if (!model) return cb("Model does not exist",null);



	if(conditions) {
		if(conditions["columns"]) {
			model = model.find(conditions["columns"]);
		} else {
			model = model.find();
		}

		if(conditions["offset"]) {
			model = model.offset(parseInt(conditions["offset"]));
		}

		if(conditions["limit"]) {
			model = model.limit(parseInt(conditions["limit"]));
		}

		if(conditions["only"]) {
			model = model.only(conditions["only"]);
		}

		if(conditions["omit"]) {
			model = model.omit(conditions["omit"]);
		}

		if(conditions["order"]) {
			model = model.order(conditions["order"]);
		}

	} else {
		model = model.find();
	}

	model.run(function(err,models) {
		
		if(err) {
			console.log(err);
            return cb("Query failed",null);
		}
		cb(null,models);
	});
};

module.exports.countByConditions = function(modelName,conditions,cb) {
	var db = databaseModule.getDatabase();

	var model = db.models[modelName];

    if (!model) return cb("Model does not exist",null);

	var resultCB = function(err,count){
		if(err) {
            return cb("Query failed",null);
		}
		cb(null,count);
	}

	if(conditions) {
		if(conditions["columns"]) {
			model = model.count(conditions["columns"],resultCB);
		} else {
			model = model.count(resultCB);
		}

	} else {
		model = model.count(resultCB);
	}

};

/**
 *Get a piece of data
 * @param  {[type]}   modelName Model name
 * @param  {[Array]}   conditions  Condition set
 * @param  {Function} cb         Call back
 */
module.exports.findOne = function(modelName,conditions,cb) {
	var db = databaseModule.getDatabase();

	var Model = db.models[modelName];

    if (!Model) return cb("Model does not exist",null);

    if (!conditions) return cb("Condition is empty",null);

	Model.one(conditions,function(err,obj){
		logger.debug(err);
		if(err) {
            return cb("Query failed",null);
		}
		return cb(null,obj);
	});
}

/**
 *Update object data
 * 
 * @param  {[type]}   modelName Model name
 * @param  {[type]}   id        Data key ID
 * @param  {[type]}   updateObj Update object data
 * @param  {Function} cb        Callback
 */
module.exports.update = function(modelName,id,updateObj,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.get(id,function(err,obj){
        if (err) return cb("Update failed",null);
		obj.save(updateObj,cb);
	});
}

/**
 * Get object by primary key ID
 * @param  {[type]}   modelName Model name
 * @param  {[type]}   id        Primary key ID
 * @param  {Function} cb        Callback
 */
module.exports.show = function(modelName,id,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.get(id,function(err,obj){
		cb(err,obj);
	});
}

/**
 * Delete object by primary key ID
 * 
 * @param  {[type]}   modelName Model name
 * @param  {[type]}   id        Primary key ID
 * @param  {Function} cb         Callback
 */
module.exports.destroy = function(modelName,id,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.get(id,function(err,obj){
        if (err) return cb("No model ID");
		obj.remove(function(err) {
            if (err) return cb("failed to delete");
			return cb(null);
		});
	});
}

/**
 * Get the number of databases by model name
 * 
 * @param  {[type]}   modelName Model name
 * @param  {Function} cb        Callback
 */
module.exports.count = function(modelName,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.count(cb);
}

/**
 * Determine if data exists by conditions
 * 
 * @param  {[type]}   modelName  Module name
 * @param  {[type]}   conditions condition
 * @param  {Function} cb         Callback
 */
module.exports.exists = function(modelName,conditions,cb) {
	var db = databaseModule.getDatabase();
	var Model = db.models[modelName];
	Model.exists(conditions,function(err,isExists){
        if (err) return cb("Query failed");
		 cb(null,isExists);
	});
}

module.exports.getModel = function(modelName) {
	var db = databaseModule.getDatabase();
	return db.models[modelName];
}