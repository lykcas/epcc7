var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(),"modules/database"));

/**
 * 获取参数列表数据 obtain list data of parameter 
 * 
 * @param  {[type]}   T_id  Game_category_id
 * @param  {Function} cb     Call back
 */
module.exports.list = function (T_id,cb) {
	db = databaseModule.getDatabase();
    sql = "SELECT * FROM mydb.game_type WHERE T_id = ?";
	database.driver.execQuery(
			sql
        , [T_id],function(err,attributes){
			if(err) return cb("Search executing error");
			cb(null,attributes);
		});
}


/**
 * 模糊查询用户数量
 * 
 * @param  {[type]}   key 关键词
 * @param  {Function} cb  回调函数
 */

module.exports.countByKey = function (key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count FROM game_type ";
    if (key) {
        sql += " WHERE T_name LIKE ?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%"], function (err, result) {
                if (err) return cb("查询执行出错");
                cb(null, result[0]["count"]);
            });
    } else {
        database.driver.execQuery(sql, function (err, result) {
            if (err) return cb("查询执行出错");
            cb(null, result[0]["count"]);
        });
    }

}


/**
 * 通过关键词查询用户
 * 
 * @param  {[type]}   key    关键词
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb     回调函数
 */
module.exports.findByKey = function (key, offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT * FROM game_type ";

    if (key) {
        sql += " WHERE T_name LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%", offset, limit], function (err, gametypes) {
                if (err) return cb("查询执行出错");
                cb(null, gametypes);
            });
    } else {
        sql += "  LIMIT ?,? ";
        database.driver.execQuery(sql, [offset, limit], function (err, gametypes) {
            if (err) return cb("查询执行出错");
            cb(null, gametypes);
        });
    }
}