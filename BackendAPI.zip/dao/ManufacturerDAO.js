var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(), "modules/database"));

/**
 * Create manufacturer
 * 
 * @param  {[type]}   obj manufacturer Info
 * @param  {Function} cb  Call Back
 */
module.exports.create = function (obj, cb) {
    daoModule.create("ManufacturerModel", obj, cb);
}

/**
 * Obtain manufacturer list
 * 
 * @param  {[type]}   conditions query filters
 * @param  {Function} cb         Call Back
 */
module.exports.list = function (conditions, cb) {
    daoModule.list("ManufacturerModel", conditions, function (err, models) {
        if (err) return cb(err, null);
        cb(null, models);
    });
}

/**
 * Get manufacturer object by query condition
 * 
 * @param  {[type]}   conditions condition
 * @param  {Function} cb         Call Back
 */
module.exports.findOne = function (conditions, cb) {
    daoModule.findOne("ManufacturerModel", conditions, cb);
}

/**
 * Search manufacturers by keywords
 * 
 * @param  {[type]}   key    keyword
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb      Call Back
 */
module.exports.findByKey = function (key, offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT * FROM manufacturer as M ";

    if (key) {
        sql += " WHERE M_name LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%", offset, limit], function (err, manufacturers) {
                if (err) return cb("Query execution error");
                cb(null, manufacturers);
            });
    } else {
        sql += " LIMIT ?,? ";
        database.driver.execQuery(sql, [offset, limit], function (err, manufacturers) {
            if (err) return cb("Query execution error");
            cb(null, manufacturers);
        });
    }
}

/**
 * Judge if a manufacturer exists
 * 
 * @param  {[type]}   M_name   manufacturer name
 * @param  {Function} cb       Call Back
 * 
 */
module.exports.exists = function (M_name, cb) {
    var db = databaseModule.getDatabase();
    var Model = db.models.ManufacturerModel;
    Model.exists({ "M_name": M_name }, function (err, isExists) {
        if (err) return cb("Searching fails");
        cb(null, isExists);
    });
}

/**
 * Fuzzy query number of manufacturers
 * 
 * @param  {[type]}   key Key word
 * @param  {Function} cb  Callback
 */
module.exports.countByKey = function (key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count FROM manufacturer";
    if (key) {
        sql += " WHERE M_name LIKE ?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%"], function (err, result) {
                if (err) return cb("Query execution error");
                cb(null, result[0]["count"]);
            });
    } else {
        database.driver.execQuery(sql, function (err, result) {
            if (err) return cb("Query execution error");
            cb(null, result[0]["count"]);
        });
    }

}

/**
 * Get manufacturer object data by ID
 * 
 * @param  {[type]}   id manufacturer primary key ID
 * @param  {Function} cb Callback
 */

module.exports.show = function (id, cb) {
    daoModule.show("ManufacturerModel", id, cb);
}

/**
 * Update manufacturer information
 * 
 * @param  {[type]}   obj Manufacturer object
 * @param  {Function} cb  Callback
 */
module.exports.update = function (obj, cb) {
    daoModule.update("ManufacturerModel", obj.M_id, obj, cb);
}

/**
 * Delete manufacturer object data
 * 
 * @param  {[type]}   id Primary key ID
 * @param  {Function} cb Callback
 */
module.exports.destroy = function (id, cb) {
    daoModule.destroy("ManufacturerModel", id, function (err) {
        if (err) return cb(err);
        return cb(null);
    });
}

/**
 * Save manufacturer information
 * 
 * @param  {[type]}   obj Manufacturer object
 * @param  {Function} cb  Call back
 */
module.exports.save = function (obj, cb) {
    daoModule.show(obj.M_id, function (err, oldObj) {
        if (err) {
            daoModule.create("ManufacturerModel", obj, cb);
        } else {
            daoModule.update("ManufacturerModel", obj.M_id, obj, cb);
        }
    })
}

/**
 * Get the number of manufacturers
 * 
 * @param  {Function} cb Call back
 */
module.exports.count = function (cb) {
    daoModule("ManufacturerModel", cb);
}