module.exports = function (db, callback) {
    // �û�ģ��
    db.define("CommunityModel", {
        C_id: { type: 'serial', key: true },
        C_name: String,
        G_id: Number,
        Commu_del: ['0', '1'],
        Found_time: String,
        Update_time: String,
        Description: String
    }, {
            table: "community"
        });
    return callback();
}