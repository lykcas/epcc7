module.exports = function(db,callback){
	// 用户模型
	db.define("GameModel",{
        G_id : {type: 'serial', key: true},
        T_id: Number,
        M_id: Number,
        is_del: ['0', '1'],	// 0: 正常 , 1: 删除
        G_name : String,
        G_price : Number,
        G_discription : String,
        G_rating : String,
        Num_of_player: Number,
        playing_time: Number,	
        age_limit : Number,
        official_web: String,
        G_pic: String

	},{
		table : "game",
	});
	return callback();
}