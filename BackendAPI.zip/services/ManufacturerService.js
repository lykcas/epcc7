var path = require("path");
var manusDAO = require(path.join(process.cwd(), "dao/ManufacturerDAO"));
var Password = require("node-php-password");
 


/**
 * Get all manufacturers
 * @param  {[type]}   conditions queey filter
 * Unified query criteria
 * conditions
	{
		"query" : Keyword query,
		"pagenum" : Pages,
		"pagesize" : Length per page
	}
 * @param  {Function} cb         Call back
 */
module.exports.getAllManufacturers = function (conditions, cb) {


    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    //Get the number of manufacturers by keywords
    manusDAO.countByKey(conditions["query"], function (err, count) {
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        manusDAO.findByKey(key, offset, limit, function (err, manufacturers) {
            var retMaunfacturers = [];
            for (idx in manufacturers) {
                var manufacturer = manufacturers[idx];
                retMaunfacturers.push({
                    "M_id": manufacturer.M_id,
                    "M_name": manufacturer.M_name,
                    "M_address": manufacturer.M_address,
                    "M_contact": manufacturer.M_contact,
                    "M_discription": manufacturer.M_discription
                    });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["manufacturers"] = retMaunfacturers;
            cb(err, resultDta);
        });
    });
}

/**
 * Create manufacturer
 * 
 * @param  {[type]}   manufacturer Manufacturer data set
 * @param  {Function} cb   Call back
 */
module.exports.createManufacturer = function (params, cb) {

    manusDAO.exists(params.M_name, function (err, isExists) {
        if (err) return cb(err);

        if (isExists) {
            return cb("Manufacturer name has already exists!");
        }

        manusDAO.create({

 
            "M_name": params.M_name,
            "password": Password.hash(params.password),
            "M_address": params.M_address,
            "M_contact": params.M_contact,
            "M_discription": params.M_discription

 

        }, function (err, manufacturer) {
            if (err) return cb("Creating fails");
            result = {
                "M_id": manufacturer.M_id,
                "M_name": manufacturer.M_name,
                "M_address": manufacturer.M_address,
                "M_contact": manufacturer.M_contact,
                "M_discription": manufacturer.M_discription
            };
            cb(null, result);
        });
    });
}

/**
 * Update manufacturer information
 * 
 * @param  {[type]}   params  manufacturer information
 * @param  {Function} cb      Call back
 */
module.exports.updateManufacturer = function (params, cb) {
    manusDAO.update(
        {
            "M_id": params.M_id,
            "M_name": params.M_name,
            "M_address": params.M_address,
            "M_contact": params.M_contact,
            "M_discription": params.M_discription
        },
        function (err, manufacturer) {
            if (err) return cb(err);
            cb(null, {

             
                "M_name": manufacturer.M_name,
                "M_address": manufacturer.M_address,
                "M_contact": manufacturer.M_contact,
                "M_discription": manufacturer.M_discription
            });
        }
    )
}

/**
 * Get manufacturer information by manufacturer ID
 * 
 * @param  {[type]}   id   manufacturer ID
 * @param  {Function} cb   Call back
 */
module.exports.getManufacturer = function (id, cb) {
    manusDAO.show(id, function (err, manufacturer) {
        if (err) return cb(err);
        if (!manufacturer) return cb("This manufacturer does not exist!");
        cb(
            null,
            {
                "M_id": manufacturer.M_id,
                "M_name": manufacturer.M_name,
                "M_address": manufacturer.M_address,
                "M_contact": manufacturer.M_contact,
                "M_discription": manufacturer.M_discription
            }
        );
    });
}

/**
 * Delete by manufacturer ID
 * 
 * @param  {[type]}   id  manufacturer ID
 * @param  {Function} cb  Call back
 */
module.exports.deleteManufacturer = function (id, cb) {
    manusDAO.destroy(id, function (err) {
        if (err) return cb("Delete fails!");
        cb(null);
    });
}



/**
 * Manufacturer login
 * @param  {[type]}   M_id    manufacturer ID
 * @param  {[type]}   password  password
 * @param  {Function} cb        Call back
 */
/*
module.exports.login = function (M_id, password, cb) {
    logger.debug('login => M_id:%s,password:%s', M_id, password);
    logger.debug(M_id);
    manusDAO.findOne({ "M_id": M_id }, function (err, manufacturer) {
        logger.debug(err);
        if (err || !user) return cb("Manufacturer ID does not exist");


        if (Password.verify(password, user.password)) {
            cb(
                null,
                {
                     "M_id": manufacturer.M_id,
                     "M_name": manufacturer.M_name,
                     "M_address": manufacturer.M_address,
                     "M_contact": manufacturer.M_contact,
                     "M_discription": manufacturer.M_discription
                }
            );
        } else {
            return cb("Wrong password!");
        }
    });
}*/