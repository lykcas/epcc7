require('mysql');
var fs = require("fs");
var orm = require("orm");
var Promise = require("bluebird");
var path = require("path");

/*
	app: application environment
    config: database configuration
    callback: callback
*/
function initialize(app,callback) {

	// Load configuration file
	var config = require('config').get("db_config");
	
	// Get database configuration from configuration
	var opts = {
		protocol : config.get("protocol"),
		host : config.get("host"),
		database : config.get("database"),
		port : config.get("port"),
		user : config.get("user"),
		password : config.get("password"),
		query : {pool: true,debug: true}
	};

	
	console.log("Database connection parameters %s",JSON.stringify(opts));

	// Initialize the ORM model
	app.use(orm.express(opts, {
		define: function (db, models, next) {

			app.db = db;
			global.database = db;

			// Get mapping file path
			var modelsPath = path.join(process.cwd(),"/models");
			
			// Read all model files
			fs.readdir(modelsPath,function(err, files) {
				// Store all loaded model functions
				var loadModelAsynFns = new Array();
				// console.log("Start loading ORM model layer files ");
				for (var i = 0; i < files.length; i++) {
					var modelPath = modelsPath + "/" +files[i];
					// console.log("Load the model %s",modelPath);
					loadModelAsynFns[i] = db.loadAsync(modelPath);
				}
				
				Promise.all(loadModelAsynFns)
				.then(function(){
					// console.log("ORM ORM model loading is complete");
					// Mount model collection

					for(var modelName in db.models){
						models[modelName] = db.models[modelName];
					}
					app.models = models;
					callback(null);
					next();
				})
				.catch(function(error){
                    console.error('Error loading module error: ' + err);
					callback(error);
					next();
				});
			});
		}
	}));	
}

module.exports.initialize = initialize;
module.exports.getDatabase = function() {
	return  global.database;
}