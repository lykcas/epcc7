//Import request module
const request = require('request')

// Automatically match the logistics company to which the waybill number belongs
function autoComNumber(orderno) {
  const url = `https://www.kuaidi100.com/autonumber/autoComNum?resultv2=1&text=${orderno}`
  return new Promise(function(resolve, reject) {
    request(url, (err, response, body) => {
      if (err) return reject({ status: 500, msg: err.message })
      // resolve(body)
      // console.log(body.num)
      body = JSON.parse(body)
        if (body.auto.length <= 0) return reject({ status: 501, msg: 'No corresponding logistics company' })
      resolve({ status: 200, msg: body.auto[0], comCode: body.auto[0].comCode })
    })
  })
}

async function getLogisticsInfo(req, res) {
  const result = await autoComNumber(req.params.orderno)

  if (result.status !== 200) {
    return {
      meta: {
        status: 500,
            message: 'Failed to obtain logistics information！'
      }
    }
  }

  const dataUrl = `https://www.kuaidi100.com/query?type=${result.comCode}&postid=${req.params.orderno}&temp=0.2595247267684455`
  request(dataUrl, (err, response, body) => {
    if (err) {
      return res.send({
        meta: {
          status: 501,
              message: 'Failed to obtain logistics information！'
        }
      })
    }
    // Success in obtaining logistics information
    return res.send({
      meta: {
        status: 200,
            message: 'Get logistics information successfully!'
      },
      data: (JSON.parse(body)).data
    })
  })
}

module.exports = {
  getLogisticsInfo
}
