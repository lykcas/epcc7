module.exports = function(db,callback){
	// 用户模型
	db.define("GameTypeModel",{
		T_id : {type: 'serial', key: true},
		T_name : String,
		T_discription: String
	},{
		table : "game_type"
	});
	return callback();
}