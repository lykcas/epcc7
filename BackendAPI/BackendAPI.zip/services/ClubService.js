var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(), "dao/DAO"));
var countbykeyDAO = require(path.join(process.cwd(), "dao/CountByKeyDAO"));
var moment = require("moment");


/**
 * ��ȡ����club
 * 
 * @param  {Function} cb      �ص�����
 */
module.exports.getAllClubs = function (conditions, cb) {
    if (!conditions.pagenum || conditions.pagenum <= 0) return cb("pagenum parameter error");
    if (!conditions.pagesize || conditions.pagesize <= 0) return cb("pagesize parameter error");

    // ͨ���ؼ��ʻ�ȡclub����
    countbykeyDAO.ClubcountByKey(conditions["query"], function (err, count) {
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        countbykeyDAO.ClubfindByKey(key, offset, limit, function (err, clubs) {
            var retClubs = [];
            for (idx in clubs) {
                var club = clubs[idx];

                retClubs.push({
                    "C_id": club.C_id,
                    "C_name": club.C_name,
                    "Founder_id": club.Founder_id,
                    "Isdel": club.Isdel,
                    "Found_time": moment(club.Found_time).format("YYYY-MM-DD HH:mm:ss"),
                    "Update_time": moment(club.Update_time).format("YYYY-MM-DD HH:mm:ss"),
                    "Description": club.Description

                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["clubs"] = retClubs;
            cb(err, resultDta);
        });
    });
}

/**
 * ��ȡ����club����
 * 
 * @param  {[type]}   id clubID
 * @param  {Function} cb �ص�����
 */
module.exports.getClubyById = function (id, cb) {
    dao.show("ClubModel", id, function (err, club) {
        if (err) return cb("��ȡclub����ʧ��");
        cb(null, club);
    })
}

/**
 * ����club
 * 
 * @param {[type]}   club club����
 * { 
 * cat_pid  => ����ID(����Ǹ���͸�ֵΪ0),
 * cat_name => ��������,
 * cat_level => �㼶 (����Ϊ 0)
 * }
 * 
 * @param {Function} cb  �ص�����
 */
module.exports.addClub = function (club, cb) {
    dao.create("ClubModel", {

        "C_name": club.C_name,
        "Founder_id": club.Founder_id,
        "Isdel": '0',
        "Found_time": club.Found_time,
        "Update_time": club.Update_time,
        " Description": club.Description

    },
        function (err, newClub) {
            if (err) return cb("����clubʧ��");
            cb(null, newClub);

        });
}

/**
 * ����club
 * 
 * @param  {[type]}   C_id  club��ID
 * @param  {[type]}   params  club��ز���
 * @param  {Function} cb      �ص�����
 */
module.exports.updateClub = function (C_id, params, cb) {
    dao.update("ClubModel", C_id,
        {

            "C_name": params.C_name,
            "Founder_id": params.Founder_id,
            "Isdel": '0',
            "Update_time": params.Update_time,
            " Description": params.Description
        },
        function (err, newClub) {
            if (err) return cb("����ʧ��");
            cb(null, newClub);
        });
}

/**
 * ɾ��club
 * 
 * @param  {[type]}   C_id   club��ID
 * @param  {Function} cb     �ص�����
 */
module.exports.deleteClub = function (C_id, cb) {
    dao.update("ClubModel", C_id, { "Isdel": 1 }, function (err, newClub) {

        if (err) return cb("ɾ��ʧ��");
        cb("ɾ���ɹ�");
    });
}
