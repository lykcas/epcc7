var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(), "modules/database"));

/**
 * Create Front end user
 * 
 * @param  {[type]}   obj User Info
 * @param  {Function} cb  Call Back
 */
module.exports.create = function (obj, cb) {
    daoModule.create("UserModel", obj, cb);
}

/**
 * Obtain user list
 * 
 * @param  {[type]}   conditions query filters
 * @param  {Function} cb         Call Back
 */
module.exports.list = function (conditions, cb) {
    daoModule.list("UserModel", conditions, function (err, models) {
        if (err) return cb(err, null);
        cb(null, models);
    });
}

/**
 * Get user object by query condition
 * 
 * @param  {[type]}   conditions condition
 * @param  {Function} cb         Call Back
 */
module.exports.findOne = function (conditions, cb) {
    daoModule.findOne("UserModel", conditions, cb);
}

/**
 * Search users by keywords
 * 
 * @param  {[type]}   key    keyword
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb      Call Back
 */
module.exports.findByKey = function (key, offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT * FROM user as U ";

    if (key) {
        sql += " WHERE username LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%", offset, limit], function (err, users) {
                if (err) return cb("Query execution error");
                cb(null, users);
            });
    } else {
        sql += " LIMIT ?,? ";
        database.driver.execQuery(sql, [offset, limit], function (err, users) {
            if (err) return cb("Query execution error");
            cb(null, users);
        });
    }
}

/**
 * Judge if a user exists
 * 
 * @param  {[type]}   username User name
 * @param  {Function} cb       Call Back
 * 
 */
module.exports.exists = function (username, cb) {
    var db = databaseModule.getDatabase();
    var Model = db.models.UserModel;
    Model.exists({ "username": username }, function (err, isExists) {
        if (err) return cb("Searching fails");
        cb(null, isExists);
    });
}

/**
 * Fuzzy query number of users
 * 
 * @param  {[type]}   key Key word
 * @param  {Function} cb  Callback
 */
module.exports.countByKey = function (key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count FROM user";
    if (key) {
        sql += " WHERE username LIKE ?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%"], function (err, result) {
                if (err) return cb("Query execution error");
                cb(null, result[0]["count"]);
            });
    } else {
        database.driver.execQuery(sql, function (err, result) {
            if (err) return cb("Query execution error");
            cb(null, result[0]["count"]);
        });
    }

}

/**
 * Get user object data by ID
 * 
 * @param  {[type]}   id User primary key ID
 * @param  {Function} cb Callback
 */
 
module.exports.show = function (id, cb) {
    daoModule.show("UserModel", id, cb);
}

/**
 * Update user information
 * 
 * @param  {[type]}   obj User object
 * @param  {Function} cb  Callback
 */
module.exports.update = function (obj, cb) {
    daoModule.update("UserModel", obj.user_id, obj, cb);
}

/**
 * Delete user object data
 * 
 * @param  {[type]}   id Primary key ID
 * @param  {Function} cb Callback
 */
module.exports.destroy = function (id, cb) {
    daoModule.destroy("UserModel", id, function (err) {
        if (err) return cb(err);
        return cb(null);
    });
}

/**
 * Save user information
 * 
 * @param  {[type]}   obj User object
 * @param  {Function} cb  Call back
 */
module.exports.save = function (obj, cb) {
    daoModule.show(obj.user_id, function (err, oldObj) {
        if (err) {
            daoModule.create("UserModel", obj, cb);
        } else {
            daoModule.update("UserModel", obj.mg_id, obj, cb);
        }
    })
}

/**
 * Get the number of users
 * 
 * @param  {Function} cb Call back
 */
module.exports.count = function (cb) {
    daoModule("UserModel", cb);
}