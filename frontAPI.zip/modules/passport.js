const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const Strategy = require('passport-http-bearer').Strategy;

var jwt = require("jsonwebtoken");

var _ = require('lodash');

var jwt_config = require("config").get("jwt_config");

// Initialized by login function
/**
 * Initialize the passport framework
 * 
 * @param  {[type]}   app       Global application
 * @param  {[type]}   loginFunc Login function
 * @param  {Function} callback  Callback
 */
module.exports.setup = function(app,loginFunc,callback) {
	// Username and password login policy
	passport.use(new LocalStrategy(
		function(username, password,done) {
            if (!loginFunc) return done("Login authentication function is not set");
            
            loginFunc(username, password,function(err,user) {
				if(err) return done(err);
				return done(null, user);
			});
		})
	);

	// token Validation strategy
	passport.use(new Strategy(
		function(token, done) {
			jwt.verify(token, jwt_config.get("secretKey"), function (err, decode) {
                if (err) { return done("Validation error"); }
				return done(null, decode);
			});
		}
 	));

	// Initialize the passport module
	app.use(passport.initialize());

	if(callback) callback();
};

/**
 * Login authentication logic
 * 
 * @param  {[type]}   req  request
 * @param  {[type]}   res  response
 * @param  {Function} next [description]
 */
module.exports.login = function(req,res,next) {

	passport.authenticate('local', function(err, user, info) {
		
		if(err) return res.sendResult(null,400,err);
        if (!user) return res.sendResult(null, 400,"Parameter error");

		// Get character information
		var token = jwt.sign({"uid":user.id,"rid":user.rid}, jwt_config.get("secretKey"), {"expiresIn": jwt_config.get("expiresIn")});
		user.token = "Bearer " + token;
        return res.sendResult(user, 200,'login successful');
	})(req, res, next);
	
}

/**
 * token验证函数
 * 
 * @param  {[type]}   req  请求对象
 * @param  {[type]}   res  响应对象
 * @param  {Function} next 传递事件函数
 */
module.exports.tokenAuth = function(req,res,next) {
	passport.authenticate('bearer', { session: false },function(err,tokenData) {
        if (err) return res.sendResult(null, 400,'Invalid  token');
        if (!tokenData) return res.sendResult(null, 400,'Invalid  token');
		req.userInfo = {};
		req.userInfo.uid = tokenData["uid"];
		req.userInfo.rid = tokenData["rid"];
		next();
	})(req, res, next);
}


/**
 * User Login authentication logic
 * 
 * @param  {[type]}   req  request
 * @param  {[type]}   res  response
 * @param  {Function} next [description]
 */
module.exports.userlogin = function (req, res, next) {

    passport.authenticate('local', function (err, user, info) {

        if (err) return res.sendResult(null, 400, err);
        if (!user) return res.sendResult(null, 400, "Parameter error");

         
        return res.sendResult(user, 200, 'login successful');
    })(req, res, next);

}
 