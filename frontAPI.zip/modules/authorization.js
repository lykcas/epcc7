var path = require('path');
// var roles_controller = require("../controllers/roles");

var path = require("path");

global.service_caches = {};

// Store global validation functions
global.service_auth_fn = null;

/**
 * Construct callback object format
 * 
 * @param {[type]} serviceName   service name
 * @param {[type]} actionName    Action name (method name)
 * @param {[type]} serviceModule Service module
 * @param {[type]} origFunc      Original method
 */
function Invocation(serviceName,actionName,serviceModule,origFunc) {
	return function() {
		var origArguments = arguments;
		return function(req,res,next) {
			if(global.service_auth_fn) {
				global.service_auth_fn(req,res,next,serviceName,actionName,function(pass) {
					if(pass) {
						origFunc.apply(serviceModule,origArguments);
					} else {
                       // res.sendResult(null, 401, "Permission verification failed");
                        origFunc.apply(serviceModule, origArguments);
					}
				});
            } else {
                origFunc.apply(serviceModule, origArguments);
               // res.sendResult(null, 401,"Permission verification failed");
			}
		}
	}
}

// Get service object
module.exports.getService = function(serviceName) {

	if(global.service_caches[serviceName]) {
		return global.service_caches[serviceName];
	}

	var servicePath = path.join(process.cwd(),"services",serviceName);
	
	var serviceModule = require(servicePath);
	if(!serviceModule) {
        console.log("Module was not found");
		return null;
	}
	global.service_caches[serviceName] = {};

	console.log("*****************************************");
    console.log("Intercept service => %s",serviceName);
	console.log("*****************************************");
	for(actionName in serviceModule) {

		if(serviceModule && serviceModule[actionName] && typeof(serviceModule[actionName]) == "function") {
			var origFunc = serviceModule[actionName];
			global.service_caches[serviceName][actionName] = Invocation(serviceName,actionName,serviceModule,origFunc);
			console.log("action => %s",actionName);
		}
	}
	// console.log(global.service_caches);
	console.log("*****************************************\n");
	return global.service_caches[serviceName];
}

// Set global validation function
module.exports.setAuthFn = function(authFn) {
	global.service_auth_fn = authFn;
}

