var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(),"dao/DAO"));

var orm = require("orm");
var Promise = require("bluebird");
var fs = require("fs");
var gm = require("gm");
var uniqid = require('uniqid');
var upload_config = require('config').get("upload_config");
/**
 * 裁剪图片
 * 
 * @param  {[type]} srcPath   原始图片路径
 * @param  {[type]} savePath  存储路径
 * @param  {[type]} newWidth  新的宽度
 * @param  {[type]} newHeight 新的高度
 * @return {[type]}           [description]
 */
function clipImage(srcPath,savePath,newWidth,newHeight) {
	return new Promise(function(resolve,reject) {
		// console.log("src => %s",srcPath);
		// console.log("save => %s",savePath);
		/*
		gm(srcPath)
		.resize(newWidth,newHeight)
		.autoOrient()
		.write(savePath,function(err){
			resolve();
		})
		
		*/
		
		// 创建读取流
		readable = fs.createReadStream(srcPath);
		// 创建写入流
		writable = fs.createWriteStream(savePath);
		readable.pipe(writable);
		readable.on('end',function() {
			resolve();
		});
		
	});
}

/**
 * 通过参数生成游戏基本信息
 * 
 * @param  {[type]} params.cb [description]
 * @return {[type]}           [description]
 */
function generateGameInfo(params) {
	return new Promise(function(resolve,reject){
        var info = {};

       // if (params.G_id) info["G_id"] = params.G_id;
        if (!params.G_name) return reject("游戏名称不能为空");
        info["G_name"] = params.G_name;

        if (!params.G_price) return reject("游戏价格不能为空");
        var price = parseFloat(params.G_price);
        if (isNaN(price) || price < 0) return reject("游戏价格不正确")
        info["G_price"] = price;

		
        if (!params.M_id) return reject("厂家编号不能为空");
        var Mid = parseInt(params.M_id);
        if (isNaN(Mid) || Mid < 0) return reject("厂家编号不正确");
        info["M_id"] = Mid;

        if (!params.T_id) return reject("游戏没有设置所属类别");
        var type = parseInt(params.T_id);
        if (isNaN(type) || type < 0) return reject("厂家编号不正确");
        info["T_id"] = type;

        if (!params.G_rating) return reject("游戏评分不能为空");
        info["G_rating"] = params.G_rating;
        
        if (params.G_discripiton) {
            info["G_discripiton"] = params.G_discripiton;
		}

      
  
        if (params.Num_of_player) {
            Numplayer = parseInt(params.Num_of_player);
            if (isNaN(Numplayer) || Numplayer < 0) return reject("游戏最大可玩人数格式不正确");
            info["Num_of_player"] = Numplayer;
		} else {
            info["Num_of_player"] = 0;
        }
        info["is_del"] = '0';

        if (params.playing_time) {
            Timeperiod = parseInt(params.playing_time);
            if (isNaN(Timeperiod) || Timeperiod < 0) return reject("游戏持续时长格式不正确");
            info["playing_time"] = Numplayer;
        } else {
            info["playing_time"] = 0;
        }
        if (params.age_limit) {
            ageMin = parseInt(params.age_limit);
            if (isNaN(ageMin) || ageMin < 0) return reject("游戏可玩年龄限制不正确");
            info["age_limit"] = ageMin;
        } else {
            info["age_limit"] = 0;
        }

        if (params.G_pic) {
            info["G_pic"] = params.G_pic;
        } else {
            info["G_pic"] = "";
        }


		resolve(info);
	});
}

/**
 * 检查游戏名称是否重复
 * 
 * @param  {[type]} info [description]
 * @return {[type]}      [description]
 */
function checkGameName(info) {
	return new Promise(function(resolve,reject) {

        dao.findOne("GameModel", { "G_name": info.G_name, "is_del": "0"},function(err,game) {
			//if(err) return reject(err);
            if (!game) return resolve(info);
            if (game.G_id == info.G_id) return resolve(info);
			return reject("游戏名称已存在");
		});
	});
}



/**
 * 检查游戏ID是否重复
 * 
 * @param  {[type]} info [description]
 * @return {[type]}      [description]
 */
function checkGameID(id,info) {
    return new Promise(function (resolve, reject) {

        dao.findOne("GameModel", { "G_id": id, "is_del": "0" }, function (err, game) {
            //if(err) return reject(err);
            if (game) return resolve(info);
            if (!game) return resolve(info);
            return reject("游戏id不存在");
        });
    });
}

/**
 * 创建游戏基本信息
 * 
 * @param  {[type]} info [description]
 * @return {[type]}      [description]
 */
function createGameInfo(info) {

	return new Promise(function(resolve,reject){
		dao.create("GameModel",_.clone(info),function(err,newGame) {
    	if(err) return reject("创建游戏基本信息失败");
            info.game = newGame;
			return resolve(info);
		});
	});
}

function updateGameInfo(info) {
	return new Promise(function(resolve,reject){
        if (!info.G_id) return reject("游戏ID不存在");
        dao.update("GameModel", info.G_id, _.clone(info), function (err, newGame) {
            if (err) return reject("更新游戏基本信息失败");
            info.game = newGame;
			return resolve(info);
		});
		
	});
}

/**
 * 获取商品对象
 * 
 * @param  {[type]} info 查询内容
 * @return {[type]}      [description]
 */
function getGameInfo(info) {
	return new Promise(function(resolve,reject){
        if (!info || !info.G_id || isNaN(info.G_id)) return reject("游戏ID格式不正确");
		
        dao.show("GameModel", info.G_id,function(err,game){
            if (err) return reject("获取游戏基本信息失败");
            info["game"] = game;
			return resolve(info);
		});
	});
}

/**
 * 删除商品图片
 * 
 * @param  {[type]} pic 图片对象
 * @return {[type]}     [description]
 */
function removeGamePic(pic) {
	return new Promise(function(resolve,reject) {
        if (!pic || !pic.remove) return reject("删除游戏图片记录失败");
		pic.remove(function(err){
			if(err) return reject("删除失败");
			resolve();
		});
	});
}

function removeGamePicFile(path) {
	return new Promise(function(resolve,reject){
		fs.unlink(path,function(err,result){
			resolve();
		});
	});
}
 
function createGamePic(pic){
	return new Promise(function(resolve,reject){
		if(!pic) return reject("图片对象不能为空");
		var GamePicModel = dao.getModel("GamePicModel");
        GamePicModel.create(pic,function(err,newPic){
			if(err) return reject("创建图片数据失败");
			resolve();
		});

	});
}
 


/**
 * 更新商品图片
 * 
 * @param  {[type]} info    参数
 * @param  {[type]} newGame 游戏基本信息
 */
function doUpdateGamePics(info) {
	return new Promise(function(resolve,reject){
        var game = info.game;
        if (!game.G_id) return reject("更新游戏图片失败");

		if(!info.pics) return resolve(info);
        dao.list("GamePicModel", { "columns": { "G_id": game.G_id}},function(err,oldpics) {
			if(err) return reject("获取商品图片列表失败");

			

			var batchFns = [];

			var newpics = info.pics ? info.pics : [];
			var newpicsKV = _.keyBy(newpics,"pics_id");
			var oldpicsKV = _.keyBy(oldpics,"pics_id");

			/**
			 * 保存图片集合
			 */
			// 需要新建的图片集合
			var addNewpics = [];
			// 需要保留的图片的集合
			var reservedOldpics = [];
			// 需要删除的图片集合
			var delOldpics = [];

			// 如果提交的新的数据中有老的数据的pics_id就说明保留数据，否则就删除
			_(oldpics).forEach(function(pic){
				if(newpicsKV[pic.pics_id]) {
					reservedOldpics.push(pic);
				} else {
					delOldpics.push(pic);
				}
			});

			// 从新提交的数据中检索出需要新创建的数据
			// 计算逻辑如果提交的数据不存在 pics_id 字段说明是新创建的数据
			_(newpics).forEach(function(pic){
				if(!pic.pics_id && pic.pic) {
					addNewpics.push(pic);
				}
			});

			// 开始处理商品图片数据逻辑
			// 1. 删除商品图片数据集合
			_(delOldpics).forEach(function(pic){
				// 1.1 删除图片物理路径
				batchFns.push(removeGamePicFile(path.join(process.cwd(),pic.pics_big)));
                batchFns.push(removeGamePicFile(path.join(process.cwd(),pic.pics_mid)));
                batchFns.push(removeGamePicFile(path.join(process.cwd(),pic.pics_sma)));
				// 1.2 数据库中删除图片数据记录
                batchFns.push(removeGamePicFile(pic));
			});

			// 2. 处理新建图片的集合
			_(addNewpics).forEach(function(pic){
				if(!pic.pics_id && pic.pic) {
					// 2.1 通过原始图片路径裁剪出需要的图片
					var src = path.join(process.cwd(),pic.pic);
					var tmp = src.split(path.sep);
					var filename = tmp[tmp.length - 1];
					pic.pics_big = "/uploads/gamespics/big_" + filename;
                    pic.pics_mid = "/uploads/gamespics/mid_" + filename;
                    pic.pics_sma = "/uploads/gamespics/sma_" + filename;
					batchFns.push(clipImage(src,path.join(process.cwd(),pic.pics_big),800,800));
					batchFns.push(clipImage(src,path.join(process.cwd(),pic.pics_mid),400,400));
					batchFns.push(clipImage(src,path.join(process.cwd(),pic.pics_sma),200,200));
                    pic.G_id = game.G_id;
					// 2.2 数据库中新建数据记录
					batchFns.push(createGamePic(pic));
				}
			});
			
			
			// 如果没有任何图片操作就返回
			if(batchFns.length == 0) {
				return resolve(info);
			}

			// 批量执行所有操作
			Promise.all(batchFns)
			.then(function(){
				resolve(info);
			})
			.catch(function(error){
				if(error) return reject(error);
			});
		
			
		});

		
	});
}




/**
 * 挂载图片
 * 
 * @param  {[type]} info [description]
 * @return {[type]}      [description]
 */
function doGetAllPics(info) {
	return new Promise(function(resolve,reject){
        var game = info.game;
        if (!game.G_id) return reject("获取游戏图片必须先获取商品信息");
		// 3. 组装最新的数据挂载在“info”中“game”对象下
        dao.list("GamePicModel", { "columns": { "G_id": game.G_id}},function(err,gamespics){

			if(err) return reject("获取所有游戏图片列表失败");
            _(gamespics).forEach(function(pic){
				if(pic.pics_big.indexOf("http") == 0) {
					pic.pics_big_url = pic.pics_big;
				} else {
					pic.pics_big_url = upload_config.get("baseURL") + pic.pics_big;
					
				}
				
				if(pic.pics_mid.indexOf("http") == 0) {
					pic.pics_mid_url = pic.pics_mid;
				} else {
					pic.pics_mid_url = upload_config.get("baseURL") + pic.pics_mid;
					
				}
				if(pic.pics_sma.indexOf("http") == 0) {
					pic.pics_sma_url = pic.pics_sma;
				} else {
					pic.pics_sma_url = upload_config.get("baseURL") + pic.pics_sma;
					
				}
				
				// pic.pics_mid_url = upload_config.get("baseURL") + pic.pics_mid;
				// pic.pics_sma_url = upload_config.get("baseURL") + pic.pics_sma;
			});
            info.game.pics = gamespics;
			resolve(info);
		});
	});
}



/**
 * 创建商品
 * 
 * @param  {[type]}   params 商品参数
 * @param  {Function} cb     回调函数
 */
module.exports.createGame = function(params,cb) {


	// 验证参数 & 生成数据
    generateGameInfo(params)
	// 检查商品名称
        .then(checkGameName)
	// 创建商品
        .then(createGameInfo)
	// 更新商品图片
	.then(doUpdateGamePics)
	// 更新商品参数
	.then(doGetAllPics)
	// 创建成功
	.then(function(info){
		cb(null,info.game);
	})
	.catch(function(err) {
		cb(err);
	});
}

/**
 * 删除商品
 * 
 * @param  {[type]}   id 商品ID
 * @param  {Function} cb 回调函数
 */
module.exports.deleteGame = function(id,cb) {
	if(!id) return cb("游戏产品ID不能为空");
    if (isNaN(id)) return cb("游戏产品ID必须为数字");
	dao.update(
		"GameModel",
		id,
		{
			'is_del':'1'
		},
		function(err){
			if(err) return cb(err);
			cb(null);
		}
	);
}

/**
 * 获取商品列表
 * 
 * @param  {[type]}   params     查询条件
 * @param  {Function} cb         回调函数
 */
module.exports.getAllGames = function(params,cb) {
	var conditions = {};
	if(!params.pagenum || params.pagenum <= 0) return cb("pagenum 参数错误");
	if(!params.pagesize || params.pagesize <= 0) return cb("pagesize 参数错误"); 

	conditions["columns"] = {};
	if(params.query) {
        conditions["columns"]["G_name"] = orm.like("%" + params.query + "%");
	}
	conditions["columns"]["is_del"] = '0';


	dao.countByConditions("GameModel",conditions,function(err,count){
		if(err) return cb(err);
		pagesize = params.pagesize;
		pagenum = params.pagenum;
		pageCount = Math.ceil(count / pagesize);
		offset = (pagenum - 1) * pagesize;
		if(offset >= count) {
			offset = count;
		}
		limit = pagesize;

		// 构建条件
		conditions["offset"] = offset;
		conditions["limit"] = limit;
        conditions["only"] = ["G_id", "G_name", "G_price", "T_id", "M_id", "official_web", "age_limit", "playing_time", "Num_of_player", "G_rating"];
        //conditions["order"] = "M_id";


		dao.list("GameModel",conditions,function(err,games){
			if(err) return cb(err);
			var resultDta = {};
			resultDta["total"] = count;
			resultDta["pagenum"] = pagenum;
            resultDta["games"] = _.map(games,function(game){
                return _.omit(game, "G_discripiton", "is_del","G_pic");
			});
			cb(err,resultDta);
		})
	});
}

/**
 * 更新游戏
 * 
 * @param  {[type]}   id     游戏ID
 * @param  {[type]}   params 参数
 * @param  {Function} cb     回调函数
 */
module.exports.updateGame = function(id,params,cb) {

    params.G_id = id;
	// 验证参数 & 生成数据
    generateGameInfo(params)
	// 检查商品名称
	// 创建商品
    updateGameInfo(params)
	// 更新商品图片
        .then(doUpdateGamePics)
	// 更新商品参数

        .then(doGetAllPics)
	// 创建成功
	.then(function(info){
		cb(null,info.game);
	})
	.catch(function(err) {
		cb(err);
	});
}

/**
 * 更新商品图片
 * 
 * @param  {[type]}   G_id 游戏ID
 * @param  {[type]}   pics     商品图片
 * @param  {Function} cb       回调函数
 */
module.exports.updateGamePics = function(G_id,pics,cb) {
	if(!G_id) return cb("游戏ID不能为空");
    if (isNaN(G_id)) return cb("游戏ID必须为数字");

    getGameInfo({"G_id":G_id,"pics":pics})
	.then(doUpdateGamePics)
	.then(doGetAllPics)
	.then(function(info){
		cb(null,info.game);
	})
	.catch(function(err) {
		cb(err);
	});
}

 
/*

module.exports.updateGoodsState = function(goods_id,cb) {
	getGoodInfo({"goods_id":goods_id,"goods_state":state})
	.then(updateGoodInfo)
	.then(doGetAllPics)
	.then(function(info){
		cb(null,info.good);
	})
	.catch(function(err) {
		cb(err);
	});
}*/




/**
 * 通过商品ID获取商品数据
 * 
 * @param  {[type]}   id 商品ID
 * @param  {Function} cb 回调函数
 */
module.exports.getGameById = function(id,cb) {
	getGameInfo({"G_id":id})
	.then(doGetAllPics)
	.then(function(info){
		cb(null,info.game);
	})
	.catch(function(err) {
		cb(err);
	});
}
