var _ = require('lodash');
var path = require("path");
var orm = require("orm");
var dao = require(path.join(process.cwd(),"dao/DAO"));

var Promise = require("bluebird");
var uniqid = require('uniqid');

function doCheckPostParams(params) {
	return new Promise(function(resolve,reject) {
		var info = {};
        if (params.p_id) info.p_id = params.p_id;

        if (!params.p_owner) return reject("Founder user ID cannot be blank");
        if (isNaN(parseInt(params.p_owner))) return reject("user ID must be number");

        if (!params.post_belong) return reject("Post ID cannot be blank");
        if (isNaN(parseInt(params.post_belong))) return reject("Post ID must be number");


        if (!params.pt_id) return reject("Post category ID cannot be empty");
        if (isNaN(parseInt(params.pt_id))) return reject("Post category ID must be number");

        if (!params.p_createtime) return reject("Post creation time cannot be empty");

        if (!params.p_updatetime) return reject("Post update time cannot be empty");

        if (!params.p_theme) return reject("Post subject cannot be empty");

        if (!params.p_status) return reject("Post status cannot be empty");

        info.p_theme = params.p_theme;
        info.p_createtime = params.p_createtime;
        info.p_updatetime = params.p_updatetime;
        info.p_owner = params.p_owner;
        info.post_belong = params.post_belong;
        info.pt_id = params.pt_id;
        info.p_status = params.p_status;  
        info.p_introduction = params.p_introduction;  
       

		resolve(info);
	});
}

function doCreatePost(info) {
	return new Promise(function(resolve,reject) {
        dao.create("PostModel", _.clone(info), function (err, newPost){
            if (err) return reject("Failed to create post");
            info.post = newPost;
			resolve(info);
		});
	});
}

function doCreatePostDetail(postDetail) {
	return new Promise(function(resolve,reject) {
        dao.create("PostDetailsModel", postDetail, function (err, newPostDetail){
            if (err) return reject("Create reply failed");
            resolve(newPostDetail);
		});
	});
} 

function doAddPostDetails(info) {

	return new Promise(function(resolve,reject) {
		
        if (!info.post) return reject("Post object was not created");

        var postDetails = info.reply;//	var orderGoods = info.goods;

        if (postDetails && postDetails.length > 0) {
			var fns = [];
         

            _(postDetails).forEach(function (postDetail){
                postDetail.p_id = info.order.p_id;
                fns.push(doCreatePostDetail(postDetail));
			});
			Promise.all(fns)
			 then(function(results){
                info.post.reply = results;
				resolve(info);
			})  
			.catch(function(error){
				if(error) return reject(error);
			});

		} else {
			resolve(info);
		}
	});
}

function doGetAllPostDetails(info) {
	return new Promise(function(resolve,reject) {
        if (!info.post) return reject("Post was not created");
		
        dao.list("PostDetailsModel", { "columns": { "p_id": info.post.p_id } }, function (err, postDetails){
			
			
            if (err) return reject("Failed to get post reply list");

            info.post.reply = postDetails;
			resolve(info);
		})
	});
}

function doGetPost(info) {
    return new Promise(function (resolve, reject) {
        dao.show("PostModel", info.p_id, function (err, newPost) {

            if (err) return reject("Failed to get post details");
            if (!newPost) return reject(" Post ID cannot exist ");
            info.post = newPost;
			resolve(info);
		})
	});
}

function doUpdatePost(info) {
	return new Promise(function(resolve,reject) {
        dao.update("PostModel", info.p_id, _.clone(info), function (err, newPost){
            if (err) return reject("Update failed");
            info.post = newPost;
			resolve(info);
		});
		
	});
} 


module.exports.createPost = function(params,cb) {
    doCheckPostParams(params)
        .then(doCreatePost)
        .then(doAddPostDetails)
	.then(function(info) {
		cb(null,info.post);
	})
	.catch(function(err) {
		cb(err);
	});
}


module.exports.getAllPosts = function(params,cb){
	var conditions = {};
    if (!params.pagenum || params.pagenum <= 0) return cb("pagenum Parameter error");
    if (!params.pagesize || params.pagesize <= 0) return cb("pagesize Parameter error"); 
	conditions["columns"] = {};
    if (params.p_owner) {
        conditions["columns"]["p_owner"] = params.p_owner;
	}

    if (params.p_status) {
        conditions["columns"]["p_status"] = params.p_status;
    }
    if (params.pt_id) {
        conditions["columns"]["pt_id"] = params.pt_id;
    }
    if (params.p_createtime) {
        conditions["columns"]["p_createtime"] = params.p_createtime;
    }
    if (params.p_updatetime) {
        conditions["columns"]["p_updatetime"] = params.p_updatetime;
    }

	 

    if (params.post_belong) {
        conditions["columns"]["post_belong"] = orm.like("%" + params.post_belong + "%");
	}

    if (params.p_theme) {
        conditions["columns"]["p_theme"] = orm.like("%" + params.p_theme + "%");
    }
    if (params.P_introduction) {
        conditions["columns"]["P_introduction"] = orm.like("%" + params.P_introduction + "%");
    }

	dao.countByConditions("PostModel",conditions,function(err,count){
		if(err) return cb(err);
		pagesize = params.pagesize;
		pagenum = params.pagenum;
		pageCount = Math.ceil(count / pagesize);
		offset = (pagenum - 1) * pagesize;
		if(offset >= count) {
			offset = count;
		}
		limit = pagesize;

		// Build conditions
		conditions["offset"] = offset;
		conditions["limit"] = limit;
		// conditions["only"] = 
        conditions["order"] = "post_belong";


        dao.list("PostModel",conditions,function(err,orders){
			if(err) return cb(err);
			var resultDta = {};
			resultDta["total"] = count;
			resultDta["pagenum"] = pagenum;
			resultDta["posts"] = _.map(orders,function(order){
				return order;//_.omit(order,);
			});
			cb(err,resultDta);
		})
	});
}

module.exports.getPost = function(pid,cb) {
    if (!pid) return cb("Post ID cannot be empty");
    if (isNaN(parseInt(pid))) return cb("Post ID must be numeric");
	
    doGetPost({ "p_id": pid})
        .then(doGetAllPostDetails)
	.then(function(info){
		cb(null,info.post);
	})
	.catch(function(err) {
		cb(err);
	});

}

module.exports.updatePost = function (pid,params,cb) {
    if (!pid) return cb("Post ID cannot be empty");
    if (isNaN(parseInt(pid))) return cb("Post ID must be numeric");
   
    params["p_id"] = pid;
    doCheckPostParams(params)
	.then(doUpdatePost)
    .then(doGetAllPostDetails)
	.then(function(info){
		cb(null,info.post);
	})
	.catch(function(err) {
		cb(err);
	});
	
}