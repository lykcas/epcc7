var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(), "dao/DAO"));
var ClubCommunityDAO = require(path.join(process.cwd(), "dao/ClubCommunityDAO"));
/**
 * ��ȡ��������
 * 
 * @param  {Function} cb      �ص�����
 */
module.exports.getAllCommunities = function (params, cb) {
    var conditions = {};
    if (!params.pagenum || params.pagenum <= 0) return cb("pagenum parameter error");
    if (!params.pagesize || params.pagesize <= 0) return cb("pagesize parameter error"); 
    conditions["columns"] = {};
    conditions["columns"]["Commu_del"] = '0';

    dao.countByConditions("CommunityModel", conditions, function (err, count) {
        if (err) return cb(err);
        pagesize = params.pagesize;
        pagenum = params.pagenum;
        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        // ��������
        conditions["offset"] = offset;
        conditions["limit"] = limit;
        conditions["only"] = ["C_id", "C_name", "G_id", "Commu_del","Description","Found_time", "Update_time"];
        //conditions["order"] = "M_id";


        dao.list("CommunityModel", conditions, function (err, communities) {
            if (err) return cb(err);
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["communities"] = _.map(communities, function (community) {
                return _.omit(community,  "Commu_del");
            });
            cb(err, resultDta);
        })
    });
}

/**
 * ��ȡ������������
 * 
 * @param  {[type]}   id ����ID
 * @param  {Function} cb �ص�����
 */
module.exports.getCommunityById = function (id, cb) {
    dao.show("CommunityModel", id, function (err, community) {
        if (err) return cb("��ȡ��������ʧ��");
        cb(null, community);
    })
}

/**
 * ��������
 * 
 * @param {[type]}   cat ��������
 * { 
 * C_name  => ��������,
 * G_id => ��ϷID,
 * Found_time => ����ʱ��
 * Update_time => ����ʱ��
* Description => ����
 * }
 * 
 * @param {Function} cb  �ص�����
 */
module.exports.addCommunity = function (community, cb) {
    dao.create("CommunityModel", {
      
        "C_name": community.C_name,
        "G_id": community.G_id,
        "Commu_del": '0',
        "Found_time": community.Found_time,
        "Update_time": community.Update_time,
        " Description": community.Description

    },
        function (err, newCommunity) {
        if (err) return cb("��������ʧ��");
            cb(null, newCommunity);

    });
}

/**
 * ��������
 * 
 * @param  {[type]}   C_id    ����ID
 * @param  {[type]}   params  ������ز���
 * @param  {Function} cb      �ص�����
 */
module.exports.updateCommnunity = function (C_id, params, cb) {
    dao.update("CommunityModel", C_id,
        {
            
            "C_name": params.C_name,
            "G_id": params.G_id,
            "Commu_del": '0', 
            "Update_time": params.Update_time,
            " Description": params.Description
        },
        function (err, newCommunity) {
        if (err) return cb("����ʧ��");
            cb(null, newCommunity);
    });
}

/**
 * ɾ������
 * 
 * @param  {[type]}   cat_id ����ID
 * @param  {Function} cb     �ص�����
 */
module.exports.deleteCommunity = function (C_id, cb) {
    dao.update("CommunityModel", C_id, { "Commu_del": 1 }, function (err, newCommunity) {

        if (err) return cb("Delete failed!");
        cb("Delete succeed!");
    });
}




/**
 * Get all communities
 * @param  {[type]}   conditions queey filter
 * Unified query criteria
 * conditions
	{
        "pt_id":  ID of what the post belongs to [1: community,2: club,3: image displaying post]
        "post_belong":community/club id
		"query" : Keyword query,
		"pagenum" : Pages,
		"pagesize" : Length per page
	}
 * @param  {Function} cb         Call back
 */
module.exports.getAllCommunityPost = function (conditions, cb) {

    if (!conditions.pt_id) return cb("post type id illegal parameter");
    if (!conditions.post_belong) return cb("CommunityID illegal parameter");
    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    //Get the number of manufacturers by keywords
    ClubCommunityDAO.CountByKey(conditions["pt_id"],conditions["post_belong"], conditions["query"], function (err, count) {
        pt_id = conditions["pt_id"];
        post_belong = conditions["post_belong"];
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);


        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        ClubCommunityDAO.findByKey(pt_id,post_belong,key,offset, limit, function (err, communityposts) {
            var retCommunityposts = [];
            for (idx in communityposts) {
                var communitypost = communityposts[idx];
                retCommunityposts.push({
                    "p_id": communitypost.p_id,
                    "p_theme": communitypost.p_theme,
                    "p_createtime": communitypost.p_createtime,
                    "p_updatetime": communitypost.p_updatetime,
                    "post_belong": communitypost.post_belong,
                    "p_introduction": communitypost.p_introduction
                    
                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["communityposts"] = retCommunityposts;
            cb(err, resultDta);
        });
    });
}