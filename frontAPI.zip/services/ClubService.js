var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(), "dao/DAO"));
var ClubCommunityDAO = require(path.join(process.cwd(), "dao/ClubCommunityDAO"));


/**
 * ��ȡ����club
 * 
 * @param  {Function} cb      �ص�����
 */
module.exports.getAllClubs = function (params, cb) {
    var conditions = {};
    if (!params.pagenum || params.pagenum <= 0) return cb("pagenum parameter error");
    if (!params.pagesize || params.pagesize <= 0) return cb("pagesize parameter error");
    conditions["columns"] = {};
    conditions["columns"]["Isdel"] = '0';

    dao.countByConditions("ClubModel", conditions, function (err, count) {
        if (err) return cb(err);
        pagesize = params.pagesize;
        pagenum = params.pagenum;
        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        // ��������
        conditions["offset"] = offset;
        conditions["limit"] = limit;
        conditions["only"] = ["C_id", "C_name", "Founder_id", "Isdel", "Description", "Found_time", "Update_time"];
        //conditions["order"] = "M_id";


        dao.list("ClubModel", conditions, function (err, clubs) {
            if (err) return cb(err);
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["clubs"] = _.map(clubs, function (club) {
                return _.omit(club, "Isdel");
            });
            cb(err, resultDta);
        })
    });
}

/**
 * ��ȡ����club����
 * 
 * @param  {[type]}   id clubID
 * @param  {Function} cb �ص�����
 */
module.exports.getClubyById = function (id, cb) {
    dao.show("ClubModel", id, function (err, club) {
        if (err) return cb("��ȡclub����ʧ��");
        cb(null, club);
    })
}

/**
 * ����club
 * 
 * @param {[type]}   club club����
 * { 
 * cat_pid  => ����ID(����Ǹ���͸�ֵΪ0),
 * cat_name => ��������,
 * cat_level => �㼶 (����Ϊ 0)
 * }
 * 
 * @param {Function} cb  �ص�����
 */
module.exports.addClub = function (club, cb) {
    dao.create("ClubModel", {

        "C_name": club.C_name,
        "Founder_id": club.Founder_id,
        "Isdel": '0',
        "Found_time": club.Found_time,
        "Update_time": club.Update_time,
        " Description": club.Description

    },
        function (err, newClub) {
            if (err) return cb("����clubʧ��");
            cb(null, newClub);

        });
}

/**
 * ����club
 * 
 * @param  {[type]}   C_id  club��ID
 * @param  {[type]}   params  club��ز���
 * @param  {Function} cb      �ص�����
 */
module.exports.updateClub = function (C_id, params, cb) {
    dao.update("ClubModel", C_id,
        {

            "C_name": params.C_name,
            "Founder_id": params.Founder_id,
            "Isdel": '0',
            "Update_time": params.Update_time,
            " Description": params.Description
        },
        function (err, newClub) {
            if (err) return cb("����ʧ��");
            cb(null, newClub);
        });
}

/**
 * ɾ��club
 * 
 * @param  {[type]}   C_id   club��ID
 * @param  {Function} cb     �ص�����
 */
module.exports.deleteClub = function (C_id, cb) {
    dao.update("ClubModel", C_id, { "Isdel": 1 }, function (err, newClub) {

        if (err) return cb("ɾ��ʧ��");
        cb("ɾ���ɹ�");
    });
}


  

/**
 * Get all club posts
 * @param  {[type]}   conditions query filter
 * Unified query criteria
 * conditions
	{
        "pt_id":  ID of what the post belongs to [1: community,2: club,3: image displaying post]
        "post_belong":community/club id
		"query" : Keyword query,
		"pagenum" : Pages,
		"pagesize" : Length per page
	}
 * @param  {Function} cb         Call back
 */
module.exports.getAllClubPost = function (conditions, cb) {

    if (!conditions.pt_id) return cb("post type id illegal parameter");
    if (!conditions.post_belong) return cb("Club ID illegal parameter");
    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    //Get the number of manufacturers by keywords
    ClubCommunityDAO.CountByKey(conditions["pt_id"], conditions["post_belong"], conditions["query"], function (err, count) {
        pt_id = conditions["pt_id"];
        post_belong = conditions["post_belong"];
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        ClubCommunityDAO.findByKey(pt_id, post_belong, key, offset, limit, function (err, clubposts) {
            var retClubposts = [];
            for (idx in clubposts) {
                var clubpost = clubposts[idx];
                retClubposts.push({
                    "p_id": clubpost.p_id,
                    "p_theme": clubpost.p_theme,
                    "p_createtime": clubpost.p_createtime,
                    "p_updatetime": clubpost.p_updatetime,
                    "post_belong": clubpost.post_belong,
                    "p_introduction": clubpost.p_introduction
                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["clubposts"] = retClubposts;
            cb(err, resultDta);
        });
    });
}

module.exports.getAllClubPostcount = function (conditions, cb) {

    if (!conditions.pt_id) return cb("post type id illegal parameter");
    if (!conditions.post_belong) return cb("Club ID illegal parameter");
    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    //Get the number of manufacturers by keywords
    ClubCommunityDAO.CountByKey(conditions["pt_id"], conditions["post_belong"], conditions["query"], function (err, count) {
        pt_id = conditions["pt_id"];
        post_belong = conditions["post_belong"];
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;  
        var resultDta = {};
        resultDta["total"] = count;
        cb(err, resultDta);
        
    });
}

