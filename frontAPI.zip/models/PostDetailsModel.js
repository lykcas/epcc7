module.exports = function(db,callback){
	// 用户模型
	db.define("PostDetailsModel",{
        pd_id : {type: 'serial', key: true},
        p_id : Number,
        U_id: Number,
        contexts : String,
        create_time : String,
        reply_id: Number
	},{
		table : "post_details"
	});
	return callback();
}