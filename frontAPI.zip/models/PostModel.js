module.exports = function(db,callback){
	// Post model
	db.define("PostModel",{
        p_id : {type: 'serial', key: true},
        p_owner : Number,
        p_theme : String,
        p_createtime: String,
        p_updatetime: String,
        post_belong: Number,
        pt_id: Number,
        p_status: String,
        P_introduction: String
	},{
            table: "post"
	});
	return callback();
}