var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(), "modules/database"));






/**
 * ģ�����������ĸ�community�е���������
 * @param  {[type]}   pt_id     ID of what the post belongs to [1: community,2: club,3: image displaying post]
 * @param  {[type]}   post_belong     ID of which communities the post belongs to
 * @param  {[type]}   key �ؼ���
 * @param  {Function} cb  �ص�����
 */
module.exports.CountByKey = function (pt_id,post_belong,key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count  FROM  mydb.post as P where   " 
 
    if (key) {
        sql += "   P.pt_id= ?  and P.post_belong= ? and p_theme LIKE ?";
        database.driver.execQuery(
            sql
            , [pt_id,post_belong,"%" + key + "%"], function (err, result) {
                if (err) return cb("��ѯִ�г���");
                cb(null, result[0]["count"]);
            });
    }

    else {
        sql += "    P.pt_id= ?    and P.post_belong = ?  ";
        database.driver.execQuery(sql, [pt_id, post_belong], function (err, result) {
            if (err) return cb("��ѯִ�г���");
            cb(null, result[0]["count"]);
        });
    }

}




/**
 * list clubs/communities post
 * 
 * @param  {[type]}   pt_id     ID of what the post belongs to [1: community,2: club,3: image displaying post]
 * @param  {[type]}   key    keyword in post theme
 * @param  {[type]}   post_belong     ID of which communities the post belongs to
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb      Call Back
 */
module.exports.findByKey = function (pt_id, post_belong,key,offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT P.p_id, p_theme, p_createtime, p_updatetime, username as Post_owner,post_belong, p_introduction  "+
    "FROM mydb.community as C, mydb.post as P, mydb.user as U  WHERE  P.post_belong = C.C_id and P.p_owner = U.user_id   "
  
    if (key) {
        sql += " and P.pt_id =? and P.post_belong =? and p_theme LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , [ pt_id,post_belong, "%"+key+"%", offset, limit], function (err, communityclubs) {
                if (err) return cb("Query execution error");
                cb(null, communityclubs);
            });
    } else {
        sql += "and P.pt_id =? and P.post_belong =?    LIMIT ?,? ";
        database.driver.execQuery(sql, [pt_id,post_belong,offset, limit], function (err, communityclubs) {
            if (err) return cb("Query execution error");
            cb(null, communityclubs);
        });
    }
}

 