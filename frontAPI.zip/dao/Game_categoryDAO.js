var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(),"modules/database"));

/**
 * 获取参数列表数据 obtain list data of parameter 
 * 
 * @param  {[type]}   T_id  Game_category_id
 * @param  {Function} cb     Call back
 */
module.exports.list = function (T_id,cb) {
	db = databaseModule.getDatabase();
    sql = "SELECT * FROM mydb.game_type WHERE T_id = ?";
	database.driver.execQuery(
			sql
        , [T_id],function(err,attributes){
			if(err) return cb("Search executing error");
			cb(null,attributes);
		});
}