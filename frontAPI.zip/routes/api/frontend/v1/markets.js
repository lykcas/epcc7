var express = require('express');
var router = express.Router();
var path = require("path");

// Get verification module
var authorization = require(path.join(process.cwd(), "/modules/authorization"));

// Get post management through verification module
var marketServ = authorization.getService("MarketService");

// post list
router.get("/",
    // Parameter verification
    function (req, res, next) {
        // Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400, "pagenum Parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400, "pagesize Parameter error");
        next();
    },
    // Business logic
    function (req, res, next) {
        var conditions = {
            "pagenum": req.query.pagenum,
            "pagesize": req.query.pagesize
        };

        if (req.query.G_id) {
            conditions["G_id"] = req.query.G_id;
        }
        if (req.query.U_id) {
            conditions["U_id"] = req.query.U_id;
        }
        if (req.query.game_condition) {
            conditions["game_condition"] = req.query.game_condition;
        }
        if (req.query.location) {
            conditions["location"] = req.query.location;
        }
        if (req.query.sending_areas) {
            conditions["sending_areas"] = req.query.sending_areas;
        }
        

        marketServ.getAllMarkets(
            conditions,
            function (err, result) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 200, "Get success");
            }
        )(req, res, next);
    }
);

// add post
router.post("/",
    // Parameter verification
    function (req, res, next) {
        next();
    },
    // Business logic
    function (req, res, next) {
        var params = req.body;
        marketServ.createMarket(params, function (err, newMarket) {//Change function
            if (err) return res.sendResult(null, 400, err);
            return res.sendResult(newMarket, 201, "Create new Market successfully");
        })(req, res, next);

    }
);

// Update  Market
router.put("/:id",
    // Parameter verification
    function (req, res, next) {
        next();
    },
    // Business logic
    function (req, res, next) {
        var params = req.body;
        marketServ.updateMarket(req.params.id, params, function (err, newMarket) {
            if (err) return res.sendResult(null, 400, err);
            return res.sendResult(newMarket, 201, "Update post successfully");
        })(req, res, next);
    }
);

router.get("/:id", function (req, res, next) {
    marketServ.getMarket(req.params.id, function (err, result) {
        if (err) return res.sendResult(null, 400, err);
        return res.sendResult(result, 200, "Get success");
    })(req, res, next);
});



module.exports = router;
