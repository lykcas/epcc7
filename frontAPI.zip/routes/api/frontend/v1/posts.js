var express = require('express');
var router = express.Router();
var path = require("path");

// Get verification module
var authorization = require(path.join(process.cwd(),"/modules/authorization"));

// Get post management through verification module
var postServ = authorization.getService("PostService");

// post list
router.get("/",
	// Parameter verification
	function(req,res,next) {
		// Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400,"pagenum Parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400,"pagesize Parameter error"); 
		next();
	},
	// Business logic
	function(req,res,next) {
		var conditions = {
			"pagenum" : req.query.pagenum,
			"pagesize" : req.query.pagesize
		};

        if (req.query.p_owner) {
            conditions["p_owner"] = req.query.p_owner;
		}
        if (req.query.p_status) {
            conditions["p_status"] = req.query.p_status;
		}
        if (req.query.post_belong) {
            conditions["post_belong"] = req.query.post_belong;
		}
        if (req.query.p_theme) {
            conditions["p_theme"] = req.query.p_theme;
		}
        if (req.query.p_createtime) {
            conditions["p_createtime"] = req.query.p_createtime;
        }
        if (req.query.p_updatetime) {
            conditions["p_updatetime"] = req.query.p_updatetime;
        }
        if (req.query.P_introduction) {
            conditions["P_introduction"] = req.query.P_introduction;
		}
        if (req.query.pt_id) {
            conditions["pt_id"] = req.query.pt_id;
		}

        postServ.getAllPosts(
			conditions,
			function(err,result){
				if(err) return res.sendResult(null,400,err);
                res.sendResult(result, 200,"Get success");
			}
		)(req,res,next);
	}
);

// add post
router.post("/",
	// Parameter verification
	function(req,res,next) {
		next();
	},
	// Business logic
	function(req,res,next) {
		var params = req.body;
        postServ.createPost(params, function (err, newPost) {//Change function
			if(err) return res.sendResult(null,400,err);
            return res.sendResult(newPost, 201,"Create post successfully");
		})(req,res,next);
		
	}
);

// Update post
router.put("/:id",
	// Parameter verification
	function(req,res,next) {
		next();
	},
	// Business logic
	function(req,res,next) {
		var params = req.body;
        postServ.updatePost(req.params.id,params,function(err,newPost){
			if(err) return res.sendResult(null,400,err);
            return res.sendResult(newPost, 201,"Update post successfully");
		})(req,res,next);
	}
);

router.get("/:id",function(req,res,next){
    postServ.getPost(req.params.id,function(err,result){
		if(err) return res.sendResult(null,400,err);
        return res.sendResult(result, 200,"Get success");
	})(req,res,next);
});



module.exports = router;
