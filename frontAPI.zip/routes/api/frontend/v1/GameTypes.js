var express = require('express');
var router = express.Router();
var path = require("path");

// 获取验证模块
var authorization = require(path.join(process.cwd(),"/modules/authorization"));

// 通过验证模块获取分类属性
var typeServ = authorization.getService("GameTypeService");



// 通过参数方式查询静态参数还是动态参数
router.get("/:id/types",
	// 验证参数
	function(req,res,next) {
		if(!req.params.id) {
			return res.sendResult(null,400,"分类ID不能为空");
		}
		if(isNaN(parseInt(req.params.id))) return res.sendResult(null,400,"分类ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		// typeServ
        typeServ.getTypes(req.params.id,function(err,attributes){
			if(err) return res.sendResult(null,400,err);
			res.sendResult(attributes,200,"obtain succeed!");
		})(req,res,next);
	}
);


// 创建参数
router.post("/types",
	// 验证参数
	function(req,res,next) {
		 
		 
		
        if (!req.body.T_name) return res.sendResult(null,400,"参数名称不能为空");
 
		/*
		if(!req.body.attr_write || (req.body.attr_write != "manual" && req.body.attr_write != "list")) {
			return res.sendResult(null,400,"参数的 attr_write 必须为 manual 或 list");
		}*/
		next();
	},
	// 业务逻辑
	function(req,res,next) {
        typeServ.createTypes(
		{
            "T_name": req.body.T_name,
			"T_id" : req.params.id,
            "T_discription": req.body.T_discription
		},
		function(err,attr) {
			if(err) return res.sendResult(null,400,err);
			res.sendResult(attr,201,"Create suceed!");
		})(req,res,next);
	}
);


// 更新参数
router.put("/:id/types",
	// 验证参数
	function(req,res,next) {
		if(!req.params.id) {
			return res.sendResult(null,400,"分类ID不能为空");
		}
		if(isNaN(parseInt(req.params.id))) return res.sendResult(null,400,"分类ID必须是数字");
        
		next();
	},
	// 业务逻辑
	function(req,res,next) {
        typeServ.updateType(
            req.params.id, 
			{
                
                "T_name": req.body.T_name,
                "T_discription": req.body.T_discription
			},
			function(err,newAttr) {
				if(err) return res.sendResult(null,400,err);
				res.sendResult(newAttr,200,"Update succeed!");
		})(req,res,next);
	}
);

// 删除参数
router.delete("/:id/types",
	// 验证参数
	function(req,res,next) {
		if(!req.params.id) {
			return res.sendResult(null,400,"分类ID不能为空");
		}
		if(isNaN(parseInt(req.params.id))) return res.sendResult(null,400,"分类ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
        typeServ.deleteType(req.params.id,function(err,newAttr) {
			if(err) return res.sendResult(null,400,err);
			res.sendResult(null,200,"删除成功");
		})(req,res,next);
	}
);

module.exports = router;